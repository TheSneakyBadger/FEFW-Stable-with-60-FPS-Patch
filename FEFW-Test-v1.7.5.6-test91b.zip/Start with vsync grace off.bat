@echo off
rem Starts Fortune's Eden with the vsync grace off (as v1.7.5.6), to compare.
cd /d "%~dp0"
set EDEN_VSYNC_GRACE_MS=0
start "" "Fortune's Eden.exe"
