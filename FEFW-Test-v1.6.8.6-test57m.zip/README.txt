Fortune's Eden (FEFW Stable with 60 FPS Patch) v1.6.8.6 - portable Windows x64 build
(Eden FE: Fortune's Weave fork, built on Duck912's eden-ns2-fe and xDarkWindx's eden-fefw 1.12)

Runs on any 64-bit Windows 10/11 PC with a Vulkan-capable GPU. No CPU-specific code
and the Microsoft C++ runtime is included, so nothing needs installing.

GETTING STARTED
1. Extract this whole folder somewhere (not inside Program Files) and run Fortune's Eden.exe.
2. Add your game folder: double-click the empty game list and choose the folder.

LEGAL USE ONLY. Piracy is not acceptable and is not supported in any way. No games, keys,
firmware or other Nintendo files are included. Use your own legally obtained copy of the game, dumped from your own
console, as loose files (exefs/romfs) or a single .nup file, with keys and firmware dumped
from that same console. Not affiliated with, endorsed by or sponsored by Nintendo, NVIDIA or AMD.
SAVES ARE STORED HERE, next to Fortune's Eden.exe (user\nand), NOT in %APPDATA%\eden.
Loose files and .nup now share the same saves. Saves made with loose files in older versions
are copied across automatically the first time.
Everything (settings, saves, shader cache) stays in the user\ folder here, so this doesn't
touch any other Eden install. To move it, move the whole folder. Deleting it deletes your saves.

SETTINGS are already set up (Emulation > Configure), so they apply however the game is dumped
or packed: the 12 GB memory layout the game needs, GPU mode Fast and ASTC recompression Auto
are always used; asynchronous shaders on, vsync Mailbox, 16x anisotropic filtering and VRAM
Usage Mode Conservative are the defaults. Settings has seven pages (General, System, Graphics,
Performance, Audio, Controls, Advanced); Game Settings only has the game's add-ons and input profiles.
Pick the resolution so the output matches your screen (1.5X for 4K).
Only controls need setting: Emulation > Configure > Controls.
The launch screen has the main ones beside Play: 60 FPS, Ultrawide, HDR (with paper white),
Upscaler, Upscaler quality, Frame generation, and a button to the Performance page.

Upscaler: Emulation > Configure > Graphics > Upscaler. Takes effect when the game starts.
- AMD FSR 3.1 (default, any card): replaces the game's own DLSS network, which takes work off
  the emulator. Its sharpening follows the FSR Sharpness slider (25%).
- Game's own DLSS: the game's own small network, run as compute passes. Some prefer its look.
- NVIDIA DLSS (GeForce RTX): the best picture by far. Choose it, then click "Download from
  NVIDIA" in the panel below the list (NVIDIA's files aren't included).
- AMD FSR 4 (AMD Radeon RX 6000/7000/9000): AMD's own FSR 4.1.2 Vulkan library from the FSR SDK
  2.4 (amd_fidelityfx_upscaler_vk.dll, signed by AMD; notice in licenses\amd-fsr4). RX 9000 cards
  run the full model, RX 7000 and RX 6000 cards an INT8 model. It needs an AMD card.
NVIDIA DLSS and FSR 4 fall back to FSR 3.1 when they can't start.

Upscaler quality (Graphics): how big the 3D scene is drawn before it's upscaled to 1440p.
Native (DLAA with NVIDIA DLSS) is the sharpest and heaviest; Ultra Quality, Quality and
Balanced (the default) are in between; Performance is the game's own 720p and the lightest.
Menus and text always stay at full size. Works at 1X resolution with FSR 3.1, NVIDIA DLSS or
FSR 4; on a laptop or older card, Performance may run better.

HDR (optional): turn on HDR in Windows, tick "HDR output (HDR10)" in Graphics and start the
game; its Brightness and UI Brightness options then work. Restart the game after changing it.

Frame generation (experimental, off by default): Graphics > Frame generation, or the launch
screen. Makes a frame between each two of the game's, so 60 FPS shows as 120, in the 3D scenes.
Needs a display faster than the game's frame rate (120 Hz or more for 60 FPS).
- AMD FSR 3.1: any card (AMD's FidelityFX SDK, MIT).
- NVIDIA DLSS: GeForce RTX 40/50 and hardware-accelerated GPU scheduling on in Windows. Choose
  it, then click "Download from NVIDIA" in the panel below the setting (NVIDIA's files aren't
  included). Falls back to AMD's.
The status bar names the one running, next to the upscaler.

60 FPS MODE AND PERFORMANCE (Fortune's Weave 1.1.0)
- 60 FPS mode (Emulation > Configure > Graphics, off by default): the game runs at up to
  60 FPS instead of its native 30. Game speed follows your real frame rate, so it stays
  correct anywhere between 30 and 60 FPS (no slow motion when your PC can't hold 60). Capes
  and hair are simulated every frame.
  Takes effect when the game starts. Made for game version 1.1.0 (build ID DB93B0125F485060);
  on other versions it turns on when every place it changes is found. It works alongside mods,
  even those that use the free space after the game's code its routines usually take; with a
  mod that changes the same game code it stays off. The older "60fps" add-on folder becomes the
  setting.
- Emulation > Configure > Performance: Reflections (Full / Reduced / Off), Turn ambient
  occlusion off, Reduced crowd detail and Reduced scenery detail: lighter versions of the
  game's own effects for PCs that can't hold the frame rate (each tick makes the game
  lighter). Nothing on disk is changed. Take effect when the game starts.
ULTRAWIDE 3440x1440 (optional, OFF by default) - for 21:9 monitors: Emulation > Configure >
Graphics, tick "Ultrawide 3440x1440 (21:9) for Fortune's Weave", then start the game and play
fullscreen. It widens the 3D camera and keeps the HUD, menus and movies centred at 16:9
(movies get black bars). Kompas9's patch (MIT, licenses\ultrawide-kompas9); only for game
version 1.1.0 (build ID DB93B0125F485060).

New in v1.6.8.6:
- 60 FPS mode: menus, windows and other UI animations, and the letters of spoken text, now
  play at their normal speed. They used to run twice as fast at 60 FPS.
- Reactive flushing is on by default (Graphics > Advanced). With it off, some effects (such as
  dust clouds in cutscenes) could jump back mid-animation. Existing settings are switched once.
- Fortune's Eden and Qt Dark themes: menu check boxes no longer overlap the text.

New in v1.6.8.5:
- 60 FPS mode works with mods whose code reaches the game's other modules (such as settings
  mods that add their own options): the game no longer freezes on Continue. Its routines now
  go in memory added after the game's last module, so no module moves.

New in v1.6.8.4:
- Pre-rendered cutscenes decode 4 frames at once again, so the busiest 1440p scenes (fire,
  fast camera moves) keep up with the voices. On PCs with many cores, the video decoder's
  threads sometimes all went to sleep with work left and the movie froze (with the game
  stuck when closed); Fortune's Eden now wakes them, so the movie carries on.

New in v1.6.8.3:
- Fixed a crash in long pre-rendered cutscenes with frame generation on (from v1.6.8.2): the
  emulator closed to the desktop about 30 seconds into the video.
- 60 FPS mode now works with mods that fill the free space after the game's code (settings
  mods, quality-of-life mods): its routines go in memory Fortune's Eden adds after the game's
  code instead of turning 60 FPS mode off.

New in v1.6.8.2:
- Video memory is cleaned up at loading screens: what the previous area used is freed when the
  next one has loaded, so memory drops at each area change instead of climbing all session.
- Earlier scenes' render targets are freed after 30 seconds unused, and small leftover images
  after 5 minutes (they were kept for good and grew by gigabytes over long sessions).
- Less waiting on the emulator in busy scenes: the game's writes to graphics memory no longer
  wait for the thread that draws (the small freezes when moving units on some CPUs, #41).
- Performance page: "Turn ambient occlusion off" (ambient occlusion stays on unless ticked;
  an earlier "off" is kept), so every tick there makes the game lighter. 60 FPS mode moves to
  the Graphics page.
- F10 no longer switches between docked and handheld (easy to hit by accident; handheld drops
  the game to 1080p). The menu item and the controller shortcut, Home+X, stay.

New in v1.6.8.1:
- Frame generation is back in Settings > Graphics (it only showed on the launch screen), with
  the "Download from NVIDIA" button for NVIDIA's frame generation files.
- AMD frame generation with HDR on: the UI no longer ghosts when the camera moves.
- NVIDIA DLSS frame generation works when a game is started again: after it has run, Play
  reopens Fortune's Eden into the game (NVIDIA's software can't be set up twice in one run).

New in v1.6.8:
- Frame generation: AMD FSR 3.1 (any card) or NVIDIA DLSS (RTX 40/50). The game's UI is kept
  still, so it doesn't ghost when the camera moves.
- The main settings are on the launch screen, beside Play.
- Video memory no longer creeps up over long sessions (drops to 10 FPS, red/green garbage or
  a crash after an hour or two, mostly on 8 GB cards): images the GPU drew into that can't be
  written back are freed when unused. NVIDIA DLSS stays on when memory is over budget.
- 60 FPS mode works with mods (it goes only where no mod writes, and turns itself off if a mod
  changes the same code), and on other game versions when all its places are found.
- About 30% less game CPU time in busy scenes; cutscene video decoding on its own thread;
  Reduced scenery detail (Performance) and Audio buffer (Audio) settings; HDR paper white;
  rumble on its own thread; the updater resumes dropped downloads.

New in v1.6.7.4:
- 60 FPS mode is built in (Settings > Performance). Game speed follows the real frame rate
  from 30 to 60 FPS, so a PC that drops below 60 no longer plays in slow motion. About 50
  places in the game that counted per frame were traced and fixed (map cursor and markers,
  menus, physics, cutscene shake, character creation and more); capes and hair are
  simulated every frame with physics scaled to the frame time.
- New Performance page: Reflections, Ambient occlusion and Reduced crowd detail.
- Video memory creeps up far less over long sessions. Freed memory is returned to the
  driver (large textures get their own allocation, smaller blocks for the rest), cleanup goes
  by the memory actually in use, unused buffers are freed, and busy scenes are cleaned up
  straight away instead of filling to the limit. This should mean fewer stutters in long
  sessions and on 8 GB cards.
- The Play button on the launch screen fits its text.

New in v1.6.7.3:
- Mouse mode: the PC mouse drives the game's Joy-Con mouse cursor (Ctrl + Enter, or the
  button at the bottom of the window; right-click it for sensitivity).
- Cutscenes decode much faster (dav1d), busy scenes such as the Saramis Guesthouse run
  faster, and NVIDIA DLSS tries again after a failure instead of giving up.

New in v1.6.7.2:
- Players who updated from v1.6.2 or earlier and were still on the game's own DLSS are
  moved to AMD FSR 3.1 (the default) once. Choosing the game's own DLSS again is kept.

New in v1.6.7.1:
- Updated installs get the tuned settings too (vsync Mailbox, asynchronous shaders on,
  16x anisotropic filtering, reactive flushing off, FSR sharpening 150%).
- Text fits in buttons and lists at Windows display scaling.

New in v1.6.7:
- A new look: Fortune's Eden theme, app icon, and a launch screen with Play, Game Settings,
  Settings and Check for Updates.
- A much shorter Settings window (six pages); Game Settings has only add-ons and input
  profiles, so the settings in Settings always apply.
- Add-ons (the 60fps mod) can be changed while the game runs, applied at the next start.

New in v1.6.6.2:
- The Saramis hub (war arc) no longer drops to 15-20 FPS on mid-range PCs: a safety check
  waited for the GPU several times a second there.

New in v1.6.6.1:
- Fixed a broken picture with NVIDIA DLSS (and FSR) in some cutscenes: the upscaler was given
  the game's motion data in the wrong format.

New in v1.6.6:
- AMD FSR 4 now really starts on Radeon RX 6000/7000/9000 cards (v1.6.4 and v1.6.5 still fell
  back to FSR 3.1).
- The status bar names the upscaler's mode, e.g. "NVIDIA DLSS - DLAA" or "AMD FSR 3.1 -
  Balanced". Upscaler quality is greyed out with the game's own DLSS, and a note says when the
  resolution means it won't apply.

New in v1.6.5:
- Upscaler quality (Graphics): Native, Ultra Quality, Quality, Balanced (the new default) or
  Performance. The 3D scene can now be drawn bigger than the game's own 720p while the menus
  and text stay at 1440p.

New in v1.6.4:
- Busy scenes run faster: each draw is prepared about 40% faster where the game draws a lot
  (the Saramis hub: 53-55 FPS before, a steady 60 with the 60 FPS mod on the test PC).
- Automatic updates: on start it checks GitHub for a newer version and asks first. Updating
  downloads it, checks it against GitHub's checksum, then restarts into the new version.
  Saves, settings, keys and mods are never touched. (Settings: "Check for updates".)
- AMD FSR 4 now starts on AMD Radeon RX 6000/7000/9000 cards (it fell back to FSR 3.1 before).

New in v1.6.3:
- A PGO build again: v1.6.2's download was built without it and ran slower on the CPU side.
- Video memory cleanup starts earlier on big cards, so long sessions stay well below the limit.
- AMD FSR 3.1 is the default upscaler, and the upscaler is one dropdown (Graphics > Upscaler).
  Updating keeps your choice.

New in v1.6.2:
- HDR output (HDR10), and optional AMD FSR 3.1 and AMD FSR 4 in place of the game's DLSS.
- Fixes from a full code review: crashes (memory corruption, GPU map and texture lifetime
  races, crash or hang after a slow stop), old saves copied across reliably, sound clicks at
  loops and battle stutter on 4-core CPUs, alpha-tested edges, missing bath-scene effects.
- 8 GB cards: far fewer texture cleanup passes, and one GPU wait per pass instead of up to 40.
- Less CPU work per frame, smaller shader-build hitches, cheats no longer pause every core.
- New defaults: Bilinear filter, anti-aliasing off, vsync Mailbox, FSR sharpness 25%.

New in v1.6.1:
- Fixes 8 GB cards dropping to about 2 FPS for minutes when a scene loads many textures at
  once: the GPU texture conversion's temporary images now have a memory limit.
- UI smearing at the screen edges while moving comes from frame generation (NVIDIA Smooth
  Motion or Lossless Scaling), not the emulator: turn it off for this program.
- The resolution options show this game's real sizes: 1X is 1440p, 1.5X 4K, 2X 5K.

New in v1.6:
- ASTC textures are re-compressed to BC3 on the GPU (from Eglantine, Duck912), so battle starts
  no longer freeze while textures convert, and Auto picks BC3 on every card (about half the video memory).
- Smoother play when video memory fills up: ASTC textures unused for 30 s are freed early.

New in v1.5.2:
- Fixes a crash inside the NVIDIA driver (nvoglv64.dll) a few minutes into some sessions with
  NVIDIA DLSS on: drawing DLSS's output could start with a framebuffer the texture cache had
  just removed. From Eglantine (Duck912).

New in v1.5.1:
- Game updates: the main menu shows the update's version (1.1.0, not 1.0.0), also for .nup
  files that don't record one; loose dumps can carry an update in an updates\<number>\ folder.
- ASTC recompression Auto (see above), and big cards may use three quarters of their video
  memory instead of about 7 GB.
- Laptops and 4-core CPUs: sound no longer stutters in battles (audio threads at top priority;
  the GPU thread split turns itself off with 4 or fewer fast cores).
- Threads wait properly on newer CPUs (from Eglantine); fewer shader hitches during fades;
  crash fixes for window resizing, failed shaders, NVIDIA depth copies and stopping the game.
- Cutscene video keeps up with the voices on slower PCs.
- Logs show frame pacing every 10 s and video memory use every minute.

Changes from upstream:
- Optional NVIDIA DLSS in place of the game's own DLSS (from Duck912's work in Eglantine).
- The sky no longer turns black after opening the map: the texture cache threw away the game's
  sky colour table while the map covered the screen, without keeping what the GPU had drawn.
  Small images the GPU drew are now always kept.
- No more recurring stutter from an experiment left on by mistake in v1.3.1 to v1.4.2 (held
  CPU writes reached the GPU a frame late, so frames came out unevenly).
- CPU Clocks (Boost/Overclock) is gone: it ran the game's clock 1.7-2x fast, so cutscene voices
  dropped out and dialogue animations ended early.
- Slightly smoother busy scenes: the GPU back thread answers most "has the GPU written here?"
  checks from a page bitmap instead of searching a tree (same answers).
- Much smaller logs: no line per frame, one line per unmapped memory read, so long sessions'
  logs stay small enough to send.
- Optional ultrawide 3440x1440 (21:9) setting, off by default: Kompas9's patch (MIT), built in.
- Bath scenes no longer lose their background: a compute shader using a shared-memory
  compare-and-swap (ATOMS.CAS) is now translated instead of skipped.
- Cutscenes keep up: AV1 videos are decoded several frames at once, so the busiest 1440p
  cutscenes no longer drop the game to about 5 FPS.
- A user folder copied from another build uses its own saves and folders here, not the old
  build's (and Open Save Data Location opens the one next to this exe).
- Smoother 60 FPS in busy scenes: texture-handle tables the game builds on the GPU and never
  changes are no longer waited for once a frame.
- Fewer shader-compile stutters: translated shaders are reused between pipelines that share
  them (Wael3rd, from PokeDinner).
- Loose-file dumps use the game's real ID, so their saves sit with .nup saves.
- Shutdown and restart fixes: no hang when the audio renderer outlives its manager
  (kraibse), and a second game in the same window no longer hangs (Takoroka); both from
  PokeDinner (an Eglantine fork). Clearer logs for missing keys and unsupported commands
  (xDarkWindx).
- Loads .nup game files (NUP loader ported from Djihads80's Eglantine, GPL-3.0).
- AMD fix: shader registers read before being written are zero, as on NVIDIA, instead of
  garbage (stray coloured patches on AMD GPUs). From Eglantine (arisqz), GPL-3.0.
- The start-up check that clears empty save profile folders no longer crashes when Windows
  refuses the delete, and never deletes a folder it could not read.

Licence: GPL-3.0-or-later (see LICENSE). The full source for this build is in source.zip.
Built with MSVC 19.51.36260 on 2026-11-13.
