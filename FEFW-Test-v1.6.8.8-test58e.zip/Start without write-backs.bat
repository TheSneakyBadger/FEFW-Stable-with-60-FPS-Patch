@echo off
cd /d "%~dp0"
rem Test 58e (issue #57): starts Fortune's Eden with the texture cache's write-backs to
rem guest memory turned off.
set "EDEN_TC_WRITEBACKS=0"
start "" "Fortune's Eden.exe"
