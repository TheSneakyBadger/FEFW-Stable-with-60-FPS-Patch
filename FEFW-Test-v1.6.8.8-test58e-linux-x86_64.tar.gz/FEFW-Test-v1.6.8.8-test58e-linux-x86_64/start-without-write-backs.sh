#!/bin/sh
# Test 58e (issue #60): starts Fortune's Eden with the texture cache's write-backs to
# game memory turned off.
cd "$(dirname "$0")" || exit 1
EDEN_TC_WRITEBACKS=0 exec ./Fortunes-Eden.AppImage "$@"
